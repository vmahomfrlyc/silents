gdjs.level1goCode = {};
gdjs.level1goCode.localVariables = [];


gdjs.level1goCode.eventsList0 = function(runtimeScene) {

};

gdjs.level1goCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();


gdjs.level1goCode.eventsList0(runtimeScene);


return;

}

gdjs['level1goCode'] = gdjs.level1goCode;
