gdjs.level2Code = {};
gdjs.level2Code.localVariables = [];


gdjs.level2Code.eventsList0 = function(runtimeScene) {

};

gdjs.level2Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();


gdjs.level2Code.eventsList0(runtimeScene);


return;

}

gdjs['level2Code'] = gdjs.level2Code;
