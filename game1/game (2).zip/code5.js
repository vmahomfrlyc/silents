gdjs.level3Code = {};
gdjs.level3Code.localVariables = [];


gdjs.level3Code.eventsList0 = function(runtimeScene) {

};

gdjs.level3Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();


gdjs.level3Code.eventsList0(runtimeScene);


return;

}

gdjs['level3Code'] = gdjs.level3Code;
