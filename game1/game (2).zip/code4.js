gdjs.level2goCode = {};
gdjs.level2goCode.localVariables = [];


gdjs.level2goCode.eventsList0 = function(runtimeScene) {

};

gdjs.level2goCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();


gdjs.level2goCode.eventsList0(runtimeScene);


return;

}

gdjs['level2goCode'] = gdjs.level2goCode;
